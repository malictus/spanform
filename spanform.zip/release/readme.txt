Spanform - Spectral Analysis for Musicians
Copyright 2000 by James Halliday
________________________________________________________________
Version 1.01 - Completed October 9, 2000

For more information contact me via email at malictus@gmail.com
________________________________________________________________

This program was written in its entirety by James Halliday, with 
the exception of the FFT algorithm, which was adapted from code 
written by Don Cross, used by permission.
________________________________________________________________
Program Description

Spanform performs FFT analysis of WAV files and saves the output
in a separate analysis file. This file can be viewed visually on
the screen or printed, and modified in a number of ways. Audio
features allow the sound file to be played while viewing the
analysis file, and playback can be monitored via a scrolling
cursor.
________________________________________________________________
Creating an analysis file

1. Make sure your audio file is in uncompressed WAV format, 8- or
   16-bit, mono or stereo, with a sampling rate of 22050Hz or
   44100 Hz. You may need to use a sound converter program first
   to get the sound into the correct format. If you aren't sure,
   try the file anyway. Spanform will tell you if the sound is not
   in the correct format.

2. To create an analysis file, choose 'Create' from the 'File'
   menu. First, choose the WAV file you wish to analyze. Then
   choose a name for the analysis file. Spanform analysis files
   use the extension 'zed'.

3. The analysis options dialog will appear. Usually the defaults
   will work. See below for a description of the options.

4. At this point, the analysis will begin. While the analysis is
   taking place, you may decide to interrupt the procedure, and
   either keep or abandon the analysis that has been
   completed, by clicking the appropriate buttons in the dialog box.

5. The analysis file has now been created. See below to find out
   how to view the file.
_________________________________________________________________
Viewing an analysis file

1. Choose 'Open' from the 'File' menu. Select an analysis file to open.

2. To alter the display, choose 'Display' from the 'Spanform' menu.
   The display options are discussed below.

3. You may open mulitple analysis files at one time. However,
   audio features will only be enabled for one file at a time.
_________________________________________________________________
Audio Functions

1. To play a sound file, choose 'Play' from the 'Audio' menu.
   The sound file that is associated with the open analysis file
   will play. Progress through the file can be monitored via
   the scrolling cursor above the analysis file.

2. To stop playback, choose 'Stop' from the 'Audio' menu. To
   change the current playback position, simply click anywhere
   on the analysis file when playback is stopped. When 'Play'
   is selected, playback will begin from the new position.

3. To restart from the beginning of the sound file, choose 'Restart'
   from the main menu.

4. Spanform remembers where the audio is on your computer for playback.
   However, if the audio file is moved, you need to tell the program
   where the sound file is. Choose 'Reassociate' from the 'Audio'
   menu to specify the new location of the sound file.
_________________________________________________________________
Analysis Options

Window - The smoothing window used when processing the FFT. Hamming
is the default.

Frame Size - The size of the FFT; must be a power of 2. Larger numbers
increase the detail in the vertical dimension (pitch). 1024 is the
default.

High Freq Cutoff - The highest frequencies usually contain no significant
data. This option allows you to keep less data, thus reducing the file 
size of the analysis file. Default cutoff is 12000Hz.

Slide - Successive FFT's are moved over by this many samples. Smaller
numbers yield greater detail in the horizontal dimension (time). This
number should always be smaller than your frame size in order to avoid
skipping samples.
_________________________________________________________________
Display Options

Pitch Display, Exponential/Linear - Allows you to view the vertical
dimension (pitch) either linearly or exponentially. The default is
exponential, since this more closely resembles the way the ear works.

Pitch Display, Hz/Letters - Toggles the vertical graph between displaying
pitch information in Hertz and using letter names (C3, C4, etc.) Default
is Hertz (Hz).

Size Sliders (Horizontal and Vertical) - Allow you to modify the size
of the analysis graph.

Sensitivity - Change how much data is shown in the graph. At the lowest
setting, only the most prominent data in each frame is displayed.

Noise Threshold - Frames of silence (and near silence) will show up
on the graph as static. To avoid this, the noise threshold cuts off
sounds below a certain volume level. If large portions of the analysis
are blank, you should reduce the threshold or turn it off entirely.
_________________________________________________________________
Recent Changes

Version 0.80 - Added All Audio Functions
Version 1.00 - Fixed a bug which caused opening an invalid file to crash the program
Version 1.01 - Fixed the pitch name display (was displaying the wrong octaves)
________________________________________________________________

Thank you for using Spanform!
